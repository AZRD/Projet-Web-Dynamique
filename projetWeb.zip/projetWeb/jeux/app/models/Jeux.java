package models;

import java.util.Date;

import io.ebean.*;
import javax.persistence.*;

import play.data.validation.Constraints.*;

@Entity
public class Jeux extends Model{
  
    private static final long serialVersionUID = 1L; 
    
    @Id
    private long id;
    
    @Required
    @Pattern(value="^[A-Z][a-z0-9 ]{2,}", message="le nom doit commencer par une majusucule")
    private String nom;
    @Required
    @Min(value=3, message="Limite d'âge est de minimum 3ans")
    private int age;

    public Jeux(){
        this.nom="CS:GO";
        this.age=16;
    }
    
    public String getnom(){
        return this.nom;
    }
    
    public void setnom(String nom){
        this.nom = nom;
    }
    
    public int getage(){
        return age;
    }
    
    
    public void setage(int age){
        this.age = age;
    }
    
    public void setId(Long id){
        this.id = id;
    }
    
    public Long getId(){
        return this.id;
    }
    
    public static Finder<Long,Jeux> find = new Finder<Long,Jeux>(Jeux.class);
    
}